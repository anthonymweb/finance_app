<?php
session_start();
include('../connection/db.php');

// Ensure the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Content-Type: application/json");
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];
$category = $_POST['category'] ?? '';
$budget_limit = $_POST['budget_limit'] ?? 0;

if ($budget_limit <= 0 || empty($category)) {
    header("Content-Type: application/json");
    echo json_encode(['error' => 'Invalid budget data']);
    exit;
}

// Check wallet balance
$walletQuery = "SELECT SUM(amount) AS total_wallet FROM wallet WHERE user_id = ?";
$stmt_wallet = $conn->prepare($walletQuery);
$stmt_wallet->bind_param("i", $user_id);
$stmt_wallet->execute();
$wallet = $stmt_wallet->get_result()->fetch_assoc();
$totalWallet = $wallet['total_wallet'] ?? 0;

if ($totalWallet < $budget_limit) {
    header("Content-Type: application/json");
    echo json_encode(['error' => 'Insufficient wallet balance']);
    exit;
}

// Deduct budget limit from wallet balance
$deductWalletQuery = "INSERT INTO wallet (user_id, amount) VALUES (?, ?)";
$stmt_deduct_wallet = $conn->prepare($deductWalletQuery);
$deducted_amount = -1 * $budget_limit; // Negative to indicate deduction
$stmt_deduct_wallet->bind_param("id", $user_id, $deducted_amount);
$stmt_deduct_wallet->execute();

// Insert the budget into the budgets table
$budgetQuery = "INSERT INTO budgets (user_id, category, budget_limit, amount_spent) VALUES (?, ?, ?, 0)";
$stmt_budget = $conn->prepare($budgetQuery);
$stmt_budget->bind_param("isd", $user_id, $category, $budget_limit);
$stmt_budget->execute();

// Log the activity
$logQuery = "INSERT INTO activity_logs (user_id, activity_type, description) VALUES (?, 'Budget Created', ?)";
$logStmt = $conn->prepare($logQuery);
$description = "Budget of UGX " . number_format($budget_limit, 0) . " set for category '$category'";
$logStmt->bind_param("is", $user_id, $description);
$logStmt->execute();

// Add notification
$message = "Budget of UGX " . number_format($budget_limit, 0) . " added under '$category'.";
addNotification($conn, $user_id, $message);

function addNotification($conn, $user_id, $message) {
    $query = "INSERT INTO notifications (user_id, message) VALUES (?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("is", $user_id, $message);
    $stmt->execute();
}

// Redirect to the view_budget.php page
header("Location: ../views/view_budget.php");
exit;
?>
