<?php
session_start();
$conn = new mysqli("localhost", "root", "", "finance_app");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $conn->real_escape_string($_POST['id']);
    $category = $conn->real_escape_string($_POST['category']);
    $amount = $conn->real_escape_string($_POST['amount']);
    $date = $conn->real_escape_string($_POST['date']);
    $description = $conn->real_escape_string($_POST['description']);

    $query = "UPDATE expenses SET category='$category', amount='$amount', date='$date', description='$description' WHERE id='$id'";

    if ($conn->query($query) === TRUE) {
        header("Location: ../views/view_expenses.php?updated=1");
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
