<?php
session_start();
include('../connection/db.php');

// Ensure the user is logged in
if (!isset($_SESSION['user_id'])) {
    $_SESSION['notification'] = "Unauthorized access.";
    header("Location: ../views/view_expenses.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$category = $_POST['category'] ?? '';
$amount = $_POST['amount'] ?? 0;
$date = $_POST['date'] ?? '';
$description = $_POST['description'] ?? '';

if ($amount <= 0 || empty($category) || empty($date)) {
    $_SESSION['notification'] = "Invalid expense data. Please try again.";
    header("Location: ../views/view_expenses.php");
    exit;
}

// Check if the expense exceeds the budget
$budgetQuery = "SELECT budget_limit, amount_spent FROM budgets WHERE user_id = ? AND category = ?";
$stmt_budget = $conn->prepare($budgetQuery);
$stmt_budget->bind_param("is", $user_id, $category);
$stmt_budget->execute();
$budget = $stmt_budget->get_result()->fetch_assoc();

$remaining_budget = $budget['budget_limit'] - $budget['amount_spent'];

if (!$budget || $remaining_budget < $amount) {
    $warning = "Warning: Your expense exceeds the remaining budget for this category by UGX " . number_format(abs($remaining_budget - $amount), 0) . ".";
} else {
    $warning = "Expense within budget.";
}

// Add the expense
$expenseQuery = "INSERT INTO expenses (user_id, category, amount, date, description) VALUES (?, ?, ?, ?, ?)";
$stmt_expense = $conn->prepare($expenseQuery);
$stmt_expense->bind_param("isdss", $user_id, $category, $amount, $date, $description);
$stmt_expense->execute();

// Update the budget
$updateBudgetQuery = "UPDATE budgets SET amount_spent = amount_spent + ? WHERE user_id = ? AND category = ?";
$stmt_update_budget = $conn->prepare($updateBudgetQuery);
$stmt_update_budget->bind_param("dis", $amount, $user_id, $category);
$stmt_update_budget->execute();

// Log the activity
$logQuery = "INSERT INTO activity_logs (user_id, activity_type, description) VALUES (?, 'Expense Added', ?)";
$logStmt = $conn->prepare($logQuery);
$logDescription = "Expense of UGX " . number_format($amount, 0) . " added for category '$category' on $date. " . $warning;
$logStmt->bind_param("is", $user_id, $logDescription);
$logStmt->execute();

// Add notification with warning
$message = "Expense of UGX " . number_format($amount, 0) . " added under '$category'. " . $warning;
addNotification($conn, $user_id, $message);

function addNotification($conn, $user_id, $message) {
    $query = "INSERT INTO notifications (user_id, message) VALUES (?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("is", $user_id, $message);
    $stmt->execute();
}

// Set a success notification and redirect to view_expenses.php
$_SESSION['notification'] = "Expense added successfully! " . $warning;
header("Location: ../views/view_expenses.php");
exit;
?>
